import org.junit.Assert;
import org.junit.Test;

import com.lizhenpeng.ioc.TypeUtil;

public class TypeUtilTest {

	@Test
	public void isNumberTest() {
		Assert.assertTrue(TypeUtil.isNumber("11111"));
	}
	
	@Test
	public void isFloat() {
		Assert.assertTrue(TypeUtil.isFloat("1.001"));
	}
}
