import org.junit.Assert;
import org.junit.Test;

import com.lizhenpeng.ioc.ClassUtil;

public class ClassUtilTest {
	
	@Test
	public void testFirstCharToLowerCase() {
		String result = "hHH";
		String circle = ClassUtil.firstCharToLowerCase("HHH");
		Assert.assertEquals(result, circle);
	}
	
}
