package com.lizhenpeng.ioc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.lizhenpeng.annotation.AutoWired;
import com.lizhenpeng.annotation.Component;
import com.lizhenpeng.annotation.SetValue;
import com.lizhenpeng.base.BeanFactoryLoaderClassException;
import com.lizhenpeng.base.BeanPropertiesConfigException;
import com.lizhenpeng.base.PropertiesFileNotFound;
import com.lizhenpeng.base.ReadXmlFileException;
import com.lizhenpeng.base.XMLFileNotFoundException;

/**
 * Bean配置加载器
 * @author 出门左转
 *
 */
public class BeanLoader {

	private BeanCache beanCache;
	private ClassLoader classLoader;
	
	public void setBeanContainer(BeanCache conatiner) {
		beanCache = conatiner;
	}
	
	public ClassLoader getClassLoader() {
		return classLoader;
	}
	
	public void setClassLoader(ClassLoader loader) {
		classLoader = loader;
	}

	public void Loader(String xmlPath) {
		if (!"".equals(xmlPath)) {
			String classLoaderPath = BeanLoader.class.getResource("/").getFile();
			String file = classLoaderPath.concat(xmlPath);
			File xmlFile = new File(file);
			if (!xmlFile.exists()) {
				throw new XMLFileNotFoundException("未找到文件"+file+"!");
			}
			try {
				readXmlResource(xmlFile);
				loadBeanClass();
			} catch (DocumentException e) {
				throw new ReadXmlFileException("解析文件"+file+"出错!",e);
			}
		}
	}
	
	private void readXmlResource(File xmlFile) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(xmlFile);
		Element rootElement = document.getRootElement();
		loadBeanConfig(rootElement);
		loadImportConfig(rootElement);
		loadScannerPackageConfig(rootElement);
	}
	
	@SuppressWarnings("all")
	private void loadBeanConfig(Element rootElement) {
		List<Element> beanElement = rootElement.elements("bean");
		Iterator<Element> iterator = beanElement.iterator();
		while (iterator.hasNext()) {
			Element element = iterator.next();
			Bean bean = new Bean();
			bean.setBeanName(element.attributeValue("name"));
			bean.setClassName(element.attributeValue("class"));
			if (element.attribute("autoWired") != null) {
				if(element.attributeValue("autoWired").equals("true")) {
					bean.setAutoWired(true);
				}
			}
			List<Element> propertyList = element.elements("property");
			Iterator<Element> propIte = propertyList.iterator();
			while (propIte.hasNext()) {
				Element prop = propIte.next();
				Property property = new Property();
				String propertiesName = prop.attributeValue("name");
				if(propertiesName == null) {
					throw new BeanPropertiesConfigException(bean.getBeanName()+"属性配置错误!");
				}
				property.setPropertyName(propertiesName);
				if (prop.attribute("value") != null) {
					property.setPropertyValue(prop.attributeValue("value"));
					property.setReference(false);
					property.setAutoWired(false);
					bean.addProperty(property);
					continue;
				}
				if (prop.attribute("ref") != null) {
					property.setPropertyValue(prop.attributeValue("ref"));
					property.setReference(true);
					property.setAutoWired(false);
					bean.addProperty(property);
					continue;
				}
				property.setAutoWired(true);
				bean.addProperty(property);
			}
			beanCache.addBean(bean);
		}
	}
	
	@SuppressWarnings("all")
	private void loadImportConfig(Element rootElement) {
		List<Element> importElement = rootElement.elements("import");
		List<String> propertiesFile = new ArrayList<String>();
		if(importElement != null) {
			Iterator<Element> importElementIte = importElement.iterator();	
			while(importElementIte.hasNext()) {
				Element element = importElementIte.next();
				if(element.attribute("value") != null) {
					propertiesFile.add(element.attributeValue("value"));
				}
			}
		}
		loadPropertiesFile(propertiesFile);
	}
	
	private void loadPropertiesFile(List<String> propertiesList) {
		String classLoaderPath = BeanLoader.class.getResource("/").getFile();
		Iterator<String> propertiesIte = propertiesList.iterator();
		while(propertiesIte.hasNext()) {
			String prop = propertiesIte.next();
			Properties propertiesLoader = new Properties();
			try {
				propertiesLoader.load(new FileInputStream(new File(classLoaderPath.concat(prop))));
				Set<Object> keySet = propertiesLoader.keySet();
				Iterator<Object> iterator = keySet.iterator();
				while(iterator.hasNext()) {
					String 	key = (String)iterator.next();
					String value = propertiesLoader.getProperty(key);
					beanCache.addProperties(key,value);
				}
			} catch (FileNotFoundException e) {
				throw new PropertiesFileNotFound("无法找到属性文件"+prop+"!");
			} catch (IOException e) {
				throw new PropertiesFileNotFound("读取属性文件"+prop+"出错!");
			}
		}	
	}
	
	@SuppressWarnings("all")
	private void loadScannerPackageConfig(Element rootElement) {
		List<Element> packageElement = rootElement.elements("package");
		List<String> packageList = new ArrayList<String>();
		if(packageElement != null) {
			Iterator<Element> packageElementIte = packageElement.iterator();	
			while(packageElementIte.hasNext()) {
				Element element = packageElementIte.next();
				if(element.attribute("value") != null) {
					packageList.add(element.attributeValue("value"));
				}
			}
		}
		scanPackage(packageList);
	}
	
	private void scanPackage(List<String> packageList) {
		Iterator<String> iterator = packageList.iterator();
		String rootPath = BeanLoader.class.getResource("/").getFile();
		while(iterator.hasNext()) {
			String packageName = iterator.next();
			String packagrDir = packageName.replace(".",File.separator);
			String classFileAbsolutePath = rootPath.concat(packagrDir).concat("/");
			scannerClass(packageName,classFileAbsolutePath);
		}
	}
	
	private void scannerClass(String basePackage,String classFileAbsolutePath) {
		File classFile = new File(classFileAbsolutePath);
		if(ClassUtil.isClassFile(classFile)) {
			String classSimpleName = classFile.getName();
			classSimpleName = classSimpleName.substring(0,classSimpleName.indexOf("."));
			String classQualityName = basePackage.concat(".").concat(classSimpleName);
			try {
				Class<?> classType = classLoader.loadClass(classQualityName);
				loaderParserBean(classType,beanCache);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		if(ClassUtil.isPackage(classFile)) {
			String[] classFileList = classFile.list();
			for(String classFileName : classFileList) {
				String curPath = classFileAbsolutePath.concat(File.separator).concat(classFileName);
				String curPackage = basePackage;
				File validateFile = new File(curPath);
				if(ClassUtil.isPackage(validateFile)) {
					curPackage = basePackage.concat(".").concat(classFileName);
				}
				scannerClass(curPackage,curPath);
			}
		}
	}
	
	private void loadBeanClass() {
		Map<String,Bean> beanCacheIns = beanCache.getBeanCache();
		Set<String> beanNameIterator = beanCacheIns.keySet();
		Iterator<String> beanIterator = beanNameIterator.iterator();
		while(beanIterator.hasNext()) {
			String beanName = beanIterator.next();
			Bean bean = beanCacheIns.get(beanName);
			try {
				Class<?> beanClass  = classLoader.loadClass(bean.getClassName());
				beanCache.addClass(beanName, beanClass);
			} catch (ClassNotFoundException e) {
				throw new BeanFactoryLoaderClassException("无法加载当前类"+beanName);
			}
		}
	}
	
	private void loaderParserBean(Class<?> classType,BeanCache beanCache) {
		if(classType.isAnnotationPresent(Component.class)) {
			String beanName = classType.getName();
			beanName = ClassUtil.firstCharToLowerCase(beanName.substring(beanName.lastIndexOf(".") + 1));
			Bean bean = new Bean();
			bean.setAutoWired(true);
			bean.setBeanName(beanName);
			bean.setClassName(classType.getName());
			Field[] properties = classType.getDeclaredFields();
			for(Field propertyField : properties) {
				if(propertyField.isAnnotationPresent(AutoWired.class)) {
					Property property = new Property();
					property.setAutoWired(true);
					property.setReference(true);
					property.setPropertyName(propertyField.getName());
					bean.addProperty(property);
				}
				if(propertyField.isAnnotationPresent(SetValue.class)) {
					Property property = new Property();
					property.setAutoWired(false);
					property.setReference(false);
					property.setPropertyName(propertyField.getName());
					SetValue setValueAnnotation = propertyField.getAnnotation(SetValue.class);
					property.setPropertyValue(setValueAnnotation.value());
					bean.addProperty(property);
				}
			}
			beanCache.addBean(bean);
		}
	}

}
