package com.lizhenpeng.ioc;

public class XmlApplicationContext {
	
	private BeanCache beanCache;
	private BeanFactory beanFactory;
	private BeanLoader beanLoader;
	
	{
		beanLoader = new BeanLoader();
		beanCache = new BeanCache();
		beanFactory = new BeanFactory();
		beanLoader.setBeanContainer(beanCache);
		beanFactory.setBeanContainer(beanCache);
	}
	
	public XmlApplicationContext(String xml) {
		loader(xml);
	}

	public void loader(String xml) {
		EasyClassLoader easyClassLoader = new EasyClassLoader();
		beanLoader.setClassLoader(easyClassLoader);
		beanLoader.Loader(xml);
	}
	
	public Object getBean(String beanName) {
		return beanFactory.getBean(beanName);
	}
	
}
