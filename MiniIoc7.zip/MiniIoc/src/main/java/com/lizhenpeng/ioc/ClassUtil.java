package com.lizhenpeng.ioc;

import java.io.File;

/**
 * 工具类
 * @author 出门左转
 *
 */
public class ClassUtil {
	
	public static boolean isClassFile(File classFile) {
		if(classFile.exists() && classFile.canRead()) {
			if(classFile.isFile()) {
				String fileName = classFile.getName();
				if(fileName.endsWith(".class")) {
					return true;
				}
			}
			return false;
		}
		return false;
	}
	
	public static boolean isPackage(File classFile) {
		if(classFile.exists() && classFile.canRead()) {
			if(classFile.isDirectory()) {
				return true;
			}
			return false;
		}
		return false;
	}
	
	public static String firstCharToLowerCase(String beanName) {
		StringBuffer buffer = new StringBuffer();
		char[] bufferData = beanName.toCharArray();
		boolean firstChar = true;
		for(char ch : bufferData) {
			if(firstChar) {
				buffer.append((char)(ch + 32));
				firstChar = false;
				continue;
			}
			buffer.append(ch);
		}
		return new String(buffer);
	}
	
}
