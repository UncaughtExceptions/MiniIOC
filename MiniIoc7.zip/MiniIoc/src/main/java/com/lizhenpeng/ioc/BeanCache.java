package com.lizhenpeng.ioc;

import java.util.HashMap;
import java.util.Map;

import com.lizhenpeng.base.BeanDefineException;

/**
 * Bean容器
 * Ioc容器
 * @author 出门左转
 *
 */
public class BeanCache {
	
	private Map<String,Bean> beanCache;
	private Map<String,Object> objectCache;
	private Map<String,Class<?>> classCache;
	private Map<String,String> propertiesCache;
	
	{
		beanCache = new HashMap<String, Bean>();
		objectCache = new HashMap<String, Object>();
		classCache = new HashMap<String, Class<?>>();
		propertiesCache = new HashMap<String, String>();
	}
	
	public boolean containBean(String bean) {
		return beanCache.containsKey(bean);
	}
	
	public void addBean(Bean bean) {
		if(beanCache.containsKey(bean.getBeanName())) {
			throw new BeanDefineException("Bean容器不可重复添加"+bean.getBeanName());
		}
		beanCache.put(bean.getBeanName(),bean);
	}
	
	public Bean getBean(String beanName) {
		if(!beanCache.containsKey(beanName)) {
			throw new BeanDefineException("Bean容器未找到"+beanName);
		}
		return beanCache.get(beanName);
	}	
	
	public void addClass(String beanClass,Class<?> classType) {
		if(classCache.containsKey(beanClass)) {
			throw new BeanDefineException("Class容器不可重复添加"+beanClass);
		}
		classCache.put(beanClass,classType);
	}
	
	public Class<?> getClass(String beanName){
		if(!classCache.containsKey(beanName)) {
			throw new BeanDefineException("Class容器未找到"+beanName);
		}
		return classCache.get(beanName);
	}
	
	public boolean containObject(String beanName) {
		return objectCache.containsKey(beanName);
	}
	
	public void addObject(String beanName,Object object) {
		if(objectCache.containsKey(beanName)) {
			throw new BeanDefineException("实例容器已经存在"+beanName);
		}
		objectCache.put(beanName,object);
	}
	
	public Object getObject(String beanName){
		if(!objectCache.containsKey(beanName)) {
			throw new BeanDefineException("实例容器无法找到对象"+beanName);
		}
		return objectCache.get(beanName);
	}
	
	public Map<String,Class<?>> getClassCahe(){
		return classCache;
	}
	
	public Map<String,Bean> getBeanCache(){
		return beanCache;
	}
	
	public void addProperties(String propertiesName,String propertiesValue) {
		propertiesCache.put(propertiesName, propertiesValue);
	}
	
	public String getProperties(String propertiesName) {
		return propertiesCache.get(propertiesName);
	}
	
}
