package com.lizhenpeng.ioc;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.lizhenpeng.base.PropertiesFileNotFound;
import com.lizhenpeng.base.BaseTypeHandler;
import com.lizhenpeng.base.SecurityHandlerNotFoundException;
import com.lizhenpeng.base.TypeCastException;

/**
 * 类型处理器
 * @author 出门左转
 *
 */
public class TypeHandler {
	
	/**
	 * 存储所有类型的处理器
	 */
	private static Map<Class<?>,BaseTypeHandler> securityHandler;
	
	private final static String formatter = "\\$\\{(.*)\\}";
	
	/**
	 * 初始化所有赋值处理器
	 */
	static {
		securityHandler = new HashMap<Class<?>, BaseTypeHandler>();
		
		securityHandler.put(byte.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setByte(bean,Byte.parseByte(value));
			}
		});
		
		securityHandler.put(Byte.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Byte(value));
			}
		});
		
		securityHandler.put(short.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setShort(bean,Short.parseShort(value));
			}
		});
		
		securityHandler.put(Short.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Short(value));
			}
		});
		
		securityHandler.put(int.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setInt(bean,Integer.parseInt(value));
			}
		});
		
		securityHandler.put(Integer.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Integer(value));
			}
		});
		
		securityHandler.put(long.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setLong(bean,Long.parseLong(value));
			}
		});
		
		securityHandler.put(Long.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Long(value));
			}
		});
		
		securityHandler.put(float.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.setFloat(bean,Float.parseFloat(value));
			}
		});
		
		securityHandler.put(Float.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.set(bean,new Float(value));
			}
		});
		
		securityHandler.put(double.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.setDouble(bean,Double.parseDouble(value));
			}
		});
		
		securityHandler.put(Double.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.set(bean,new Double(value));
			}
		});
		
		securityHandler.put(char.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				field.setChar(bean,value.charAt(0));
			}
		});
		
		securityHandler.put(Character.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				field.setChar(bean,new Character(value.charAt(0)));
			}
		});
		
		securityHandler.put(String.class,new BaseTypeHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				field.set(bean, value);
			}
		});
		
	}
	
	public static void secureAssignment(BeanCache beanCache,Field field,Object bean,String value) {
		if(!securityHandler.containsKey(field.getType())) {
			throw new SecurityHandlerNotFoundException("未找到针对类型"+field.getType().toString()+"的赋值处理器!");
		}
		Pattern importResourceFormat = Pattern.compile(formatter);
		Matcher matcher = importResourceFormat.matcher(value);
		if(matcher.find()) {
			String referenceChar = matcher.group(1);
			String realyValue = beanCache.getProperties(referenceChar);
			if(realyValue == null) {
				throw new PropertiesFileNotFound("属性"+referenceChar+"未找到!");
			}
			value = realyValue;
		}
		BaseTypeHandler handler = securityHandler.get(field.getType());
		try {
			handler.handler(field,bean,value);
		} catch (NumberFormatException e) {
			throw new TypeCastException("数字类型转换错误!",e);
		} catch (IllegalArgumentException e) {
			throw new TypeCastException("参数异常!",e);
		} catch (IllegalAccessException e) {
			throw new TypeCastException("访问对象属性出错!",e);
		}
	}
	
}
