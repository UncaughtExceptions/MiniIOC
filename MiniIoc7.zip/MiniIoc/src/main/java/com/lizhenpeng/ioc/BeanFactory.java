package com.lizhenpeng.ioc;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lizhenpeng.base.BeanFactoryCreateBeanException;
import com.lizhenpeng.base.BeanNotFoundException;
import com.lizhenpeng.base.TypeCastException;

/**
 * Bean工厂
 * @author 出门左转
 *
 */
public class BeanFactory {
	
	private BeanCache beanCache;
	
	public void setBeanContainer(BeanCache conatiner) {
		beanCache = conatiner;
	}
	
	private void createBean(String beanName) {
		if(beanCache.containObject(beanName)) {
			return;
		}
		Bean bean = beanCache.getBean(beanName);
		String propertyName = null;
		if(bean == null) {
			throw new BeanNotFoundException("容器中未找到命名为"+beanName+"的Bean");
		}
		try {
			Class<?> beanClass = beanCache.getClass(beanName);
			Object beanIns = beanClass.newInstance();
			List<Property> properties = bean.getProperties();
			Iterator<Property> propIte = properties.iterator();
			while(propIte.hasNext()) {
				Property property = propIte.next();
 				propertyName = property.getPropertyName();
				if(bean.isAutoWired() && property.isAutoWired()) {
					Field field = beanClass.getDeclaredField(propertyName);
					Class<?> propertyClass = field.getType();
					Map<String,Class<?>> beanClassCache = beanCache.getClassCahe();
					Set<String> beanNameSet = beanClassCache.keySet();
					Iterator<String> beanIterator = beanNameSet.iterator();
					while(beanIterator.hasNext()) {
						String compareBean = beanIterator.next();
						Class<?> compareBeanClass = beanCache.getClass(compareBean);
						if(propertyClass == compareBeanClass && !propertyClass.isInterface()) {
							createBean(compareBean);
							Object reflectBean = beanCache.getObject(beanName);
							field.setAccessible(true);
							field.set(beanIns,reflectBean);
							continue;
						}
						if(propertyClass.isAssignableFrom(compareBeanClass) && !compareBeanClass.isInterface()) {
							createBean(compareBean);
							Object reflectBean = beanCache.getObject(compareBean);
							field.setAccessible(true);
							field.set(beanIns,reflectBean);
							continue;
						}
					}
				}else {
					String propertyValue = property.getPropertyValue();
					Field propertyField = beanClass.getDeclaredField(propertyName);
					propertyField.setAccessible(true);
					if(!property.isReference()) {
						TypeHandler.secureAssignment(beanCache,propertyField,beanIns,propertyValue);
					}else {
						createBean(property.getPropertyValue());
						Object afixProperty = beanCache.getObject(property.getPropertyValue());
						propertyField.set(beanIns,afixProperty);
					}
				}
			}
			beanCache.addObject(beanName,beanIns);
		} catch (InstantiationException e) {
			throw new BeanFactoryCreateBeanException("实例化类对象"+bean.getBeanName()+"出错");
		} catch (IllegalAccessException e) {
			throw new TypeCastException("访问对象属性出错!",e);
		} catch (NoSuchFieldException e) {
			throw new BeanFactoryCreateBeanException(bean.getBeanName()+"字段"+propertyName+"不存在");
		} catch (SecurityException e) {
			throw new BeanFactoryCreateBeanException(bean.getBeanName()+"赋值管理器赋值失败");
		}
	}
	
	public Object getBean(String beanName) {
		if(beanCache.containBean(beanName)) {
			createBean(beanName);
			return beanCache.getObject(beanName);
		}
		throw new BeanFactoryCreateBeanException("Bean容器未找到"+beanName);
	}
	
}
