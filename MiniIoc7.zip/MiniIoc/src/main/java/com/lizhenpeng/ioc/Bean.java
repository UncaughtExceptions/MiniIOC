package com.lizhenpeng.ioc;

import java.util.ArrayList;
import java.util.List;

/**
 * Bean的具体实现
 * 如果两个beanName相同则只会加载一次
 * @author 出门左转
 * 
 */
public class Bean {
	
	private String beanName;
	private String className;
	private List<Property> properties;
	private boolean AutoWired;
	private String factoryMethod;
	private String destoryMethod;
	
	{
		properties = new ArrayList<Property>();
		AutoWired = false;
	}
	
	public boolean isAutoWired() {
		return AutoWired;
	}

	public void setAutoWired(boolean autoWired) {
		AutoWired = autoWired;
	}
	
	public String getBeanName() {
		return beanName;
	}
	
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	
	public List<Property> getProperties() {
		return properties;
	}
	
	public void addProperty(Property property) {
		properties.add(property);
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getFactoryMethod() {
		return factoryMethod;
	}

	public void setFactoryMethod(String factoryMethod) {
		this.factoryMethod = factoryMethod;
	}

	public String getDestoryMethod() {
		return destoryMethod;
	}

	public void setDestoryMethod(String destoryMethod) {
		this.destoryMethod = destoryMethod;
	}

	@Override
	public int hashCode() {
		if(beanName == null) {
			return super.hashCode();
		}
		return beanName.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof Bean) {
			Bean bean = (Bean)obj;
			if(bean.getBeanName().equals(beanName)) {
				return true;
			}
		}
		return false;
	}
	
}
