package com.lizhenpeng.ioc;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import com.lizhenpeng.base.ScannerClassException;

/**
 * 文件流类加载器
 * @author 出门左转
 */
public class EasyClassLoader extends ClassLoader{
	
	private String classFilePath;
	
	public void easyLoaderClass(String className,String classFileAbsolutePath) {
		classFilePath = classFileAbsolutePath;
		try {
			loadClass(className);
		} catch (ClassNotFoundException e) {
			throw new ScannerClassException("EasyClassLoader加载"+className+"失败",e);
		}
	}
	
	@Override
	protected Class<?> findClass(String className) throws ClassNotFoundException {
		File classFile = new File(classFilePath);
		if(classFile.exists() && classFile.canRead()) {
			try {
				ByteArrayOutputStream classData = new ByteArrayOutputStream();
				int hasRead = -1;
				byte[] buffer = new byte[2048];
				BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(classFile));
				while((hasRead = inputStream.read(buffer)) > 0) {
					classData.write(buffer,0,hasRead);
				}
				byte[] classCompleteData = classData.toByteArray();
				inputStream.close();
				classData.close();
				return defineClass(className,classCompleteData,0,classCompleteData.length);

			}catch (Exception e) {
				throw new ScannerClassException("EasyClassLoader加载"+className+"出现IO错误");
			}
		}
		throw new ScannerClassException("类"+className+"不存在或者不可读");
	}
	
}
