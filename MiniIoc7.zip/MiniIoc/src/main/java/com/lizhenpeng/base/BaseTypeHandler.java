package com.lizhenpeng.base;

import java.lang.reflect.Field;

public interface BaseTypeHandler {
	public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException;
}
