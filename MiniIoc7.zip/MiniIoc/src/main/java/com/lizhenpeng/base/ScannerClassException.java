package com.lizhenpeng.base;

/**
 * 扫包加载类时出现错误
 * @author 出门左转
 *
 */
public class ScannerClassException extends RuntimeException{
	
	public ScannerClassException(String errorMessage,Throwable e) {
		super(errorMessage,e);
	}
	
	public ScannerClassException(String errorMessage) {
		super(errorMessage);
	}
	
}
