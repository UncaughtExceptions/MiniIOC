package com.lizhenpeng.base;

/**
 * 类型转换出错异常
 * @author 出门左转
 *
 */
public class TypeCastException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TypeCastException(String errorMessage) {
		super(errorMessage);
	}
	
	public TypeCastException(String errorMessage,Throwable throwable) {
		super(errorMessage);
	}
}
