package com.lizhenpeng.base;

/**
 * Bean异常
 * @author 出门左转
 *
 */
public class BeanDefineException extends RuntimeException{
	public BeanDefineException(String errorMessage) {
		super(errorMessage);
	}
}
