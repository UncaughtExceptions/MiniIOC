package com.lizhenpeng.test;

import com.lizhenpeng.annotation.AutoWired;
import com.lizhenpeng.annotation.Component;

@Component
public class TestAutoWired {
	
	@AutoWired
	private AInterface aInterface;
	@AutoWired
	private BInterface bInterface;
	
	public void call() {
		aInterface.callA();
		bInterface.callB();
	}
	
}
