package com.lizhenpeng.test;

public interface BInterface {
	public void callB();
}
