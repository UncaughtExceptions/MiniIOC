package com.lizhenpeng.test;

import com.lizhenpeng.annotation.Component;
import com.lizhenpeng.annotation.SetValue;

@Component
public class BImpl implements BInterface{
	
	@SetValue("this is B")
	private String say;
	
	public void callB() {
		System.out.println(say);
	}
}
