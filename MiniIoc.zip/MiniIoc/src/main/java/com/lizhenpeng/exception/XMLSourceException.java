package com.lizhenpeng.exception;

/**
 * XML文件未找到
 * @author 出门左转
 */
public class XMLSourceException extends RuntimeException{
	public XMLSourceException(String message) {
		super(message);
	}
}
