package com.lizhenpeng.ioc;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;

/**
 * Bean工厂
 * @author 出门左转
 *
 */
public class BeanFactory {
	
	private BeanConatiner beanConatiner;
	private ClassLoader classLoader;
	
	public void setBeanContainer(BeanConatiner conatiner) {
		beanConatiner = conatiner;
		classLoader = Thread.currentThread().getContextClassLoader();
	}
	
	private void createBean(String beanName) {
		try {
			if(beanConatiner.containIoc(beanName)) {
				return;
			}
			Bean bean = beanConatiner.getBean(beanName);
			String beanQualityName = bean.getBeanQualityName();
			Class<?> beanClass = classLoader.loadClass(beanQualityName);
			Object beanIns = beanClass.newInstance();
			List<Property> properties = bean.getProperties();
			Iterator<Property> propIte = properties.iterator();
			while(propIte.hasNext()) {
				Property property = propIte.next();
				String propertyName = property.getPropertyName();
				String propertyValue = property.getPropertyValue();
				Field propertyField = beanClass.getDeclaredField(propertyName);
				propertyField.setAccessible(true);
				if(!property.isReference()) {
					ReflectUtil.setValue(propertyField, beanIns,propertyValue);
				}else {
					createBean(property.getPropertyValue());
					Object afixProperty = beanConatiner.getIoc(property.getPropertyValue());
					propertyField.set(beanIns,afixProperty);
				}
			}
			beanConatiner.addIoc(beanName,beanIns);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
	}
	
	public Object getBean(String beanName) {
		if(!beanConatiner.containIoc(beanName)) {
			createBean(beanName);
		}
		return beanConatiner.getIoc(beanName);
	}
	
}
