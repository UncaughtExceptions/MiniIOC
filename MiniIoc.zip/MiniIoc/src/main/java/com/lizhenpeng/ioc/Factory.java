package com.lizhenpeng.ioc;

/**
 * 通用工厂对象
 * @author 出门左转
 *
 */
public class Factory {
	
	public static BeanConatiner createBeanContainer() {
		return new BeanConatiner();
	}
	
}
