package com.lizhenpeng.ioc;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 类的属性字段赋合适的值
 * @author 出门左转
 */
interface MatchFiled{
	void match(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException;
}

public class ReflectUtil {
	
	private static List<MatchFiled> matchList;
	
	static {
		matchList = new ArrayList<MatchFiled>();
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == byte.class) {
					field.setAccessible(true);
					field.setByte(bean,Byte.parseByte(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == short.class) {
					field.setAccessible(true);
					field.setShort(bean,Short.parseShort(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == int.class) {
					field.setAccessible(true);
					field.setInt(bean,Integer.parseInt(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == long.class) {
					field.setAccessible(true);
					field.setLong(bean,Long.parseLong(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == float.class) {
					field.setAccessible(true);
					field.setFloat(bean,Float.parseFloat(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == double.class) {
					field.setAccessible(true);
					field.setDouble(bean,Double.parseDouble(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Byte.class) {
					field.setAccessible(true);
					field.set(bean,new Byte(Byte.parseByte(value)));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Short.class) {
					field.setAccessible(true);
					field.set(bean,new Short(Short.parseShort(value)));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Integer.class) {
					field.setAccessible(true);
					field.set(bean,Integer.parseInt(value));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Long.class) {
					field.setAccessible(true);
					field.set(bean,new Long(Long.parseLong(value)));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Float.class) {
					field.setAccessible(true);
					field.set(bean,new Float(Float.parseFloat(value)));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Double.class) {
					field.setAccessible(true);
					field.set(bean,new Double(Double.parseDouble(value)));
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == String.class) {
					field.setAccessible(true);
					field.set(bean, value);
				}
			}
		});
		
		matchList.add(new MatchFiled() {
			public void match(Field field,Object bean, String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				if(field.getType() == Boolean.class) {
					field.setAccessible(true);
					field.set(bean,new Boolean(Boolean.parseBoolean(value)));
				}
			}
		});
	}
	
	public static void setValue(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
		Iterator<MatchFiled> iterator = matchList.iterator();
		while(iterator.hasNext()) {
			MatchFiled matcher = iterator.next();
			matcher.match(field,bean,value);
		}
	}
	
}
