package com.lizhenpeng.ioc;

/**
 * Bean属性实现类
 * @author 出门左转
 */
public class Property {
	
	private String propertyName;
	private String propertyValue;
	private boolean isReference;
	
	public String getPropertyName() {
		return propertyName;
	}
	
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	
	public String getPropertyValue() {
		return propertyValue;
	}
	
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	public boolean isReference() {
		return isReference;
	}
	
	public void setReference(boolean isReference) {
		this.isReference = isReference;
	}
	
}
