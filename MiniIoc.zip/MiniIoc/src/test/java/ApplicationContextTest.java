import org.junit.Test;

import com.lizhenpeng.ioc.XmlApplicationContext;
import com.lizhenpeng.test.First;

public class ApplicationContextTest {
	
	@Test
	public void getBeanTest() {
		XmlApplicationContext context = new XmlApplicationContext();
		context.loader("beans.xml");
		First first = (First)context.getBean("first");
		first.callAll();
	}
	
}
