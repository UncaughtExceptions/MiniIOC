import org.junit.Test;

import com.lizhenpeng.ioc.BeanConatiner;
import com.lizhenpeng.ioc.BeanFactory;
import com.lizhenpeng.ioc.BeanLoader;
import com.lizhenpeng.test.First;

public class BeanFactoryTest {

	@Test
	public void getBeanTest() {
		BeanConatiner conatiner = new BeanConatiner();
		BeanLoader beanLoader = new BeanLoader();
		beanLoader.setBeanContainer(conatiner);
		beanLoader.Loader("beans.xml");
		BeanFactory factory = new BeanFactory();
		factory.setBeanContainer(conatiner);
		First ins = (First) factory.getBean("first");
		ins.callAll();
	}
	
}
