import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Test;

import com.lizhenpeng.ioc.XmlApplicationContext;

public class ApplicationContextTest {
	
	@Test
	public void getBeanTest() throws SQLException, ParseException {
		XmlApplicationContext context = new XmlApplicationContext();
		context.loader("beans.xml");
		BasicDataSource dataSource = (BasicDataSource)context.getBean("dbcp");
		Connection connection = (Connection) dataSource.getConnection();
		String sql = "select now()";
		Statement statement = (Statement) connection.createStatement();
		ResultSet set = statement.executeQuery(sql);
		while(set.next()) {
			System.out.println(set.getString(1));
		}
		statement.close();
	}
	
}
