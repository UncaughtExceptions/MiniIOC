package com.lizhenpeng.ioc;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.lizhenpeng.base.SecurityHandler;
import com.lizhenpeng.base.SecurityHandlerNotFoundException;
import com.lizhenpeng.base.TypeCastException;

/**
 * 安全处理器
 * @author 出门左转
 *
 */
public class Security {
	
	/**
	 * 存储所有类型的处理器
	 */
	private static Map<Class<?>,SecurityHandler> securityHandler;
	
	/**
	 * 初始化所有赋值处理器
	 */
	static {
		securityHandler = new HashMap<Class<?>, SecurityHandler>();
		
		securityHandler.put(byte.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setByte(bean,Byte.parseByte(value));
			}
		});
		
		securityHandler.put(Byte.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Byte(value));
			}
		});
		
		securityHandler.put(short.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setShort(bean,Short.parseShort(value));
			}
		});
		
		securityHandler.put(Short.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Short(value));
			}
		});
		
		securityHandler.put(int.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setInt(bean,Integer.parseInt(value));
			}
		});
		
		securityHandler.put(Integer.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Integer(value));
			}
		});
		
		securityHandler.put(long.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.setLong(bean,Long.parseLong(value));
			}
		});
		
		securityHandler.put(Long.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个整型数字!");
				}
				field.set(bean,new Long(value));
			}
		});
		
		securityHandler.put(float.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.setFloat(bean,Float.parseFloat(value));
			}
		});
		
		securityHandler.put(Float.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.set(bean,new Float(value));
			}
		});
		
		securityHandler.put(double.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.setDouble(bean,Double.parseDouble(value));
			}
		});
		
		securityHandler.put(Double.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				if(!TypeUtil.isFloat(value) && !TypeUtil.isNumber(value)) {
					throw new TypeCastException(value+"不是一个数字!");
				}
				field.set(bean,new Double(value));
			}
		});
		
		securityHandler.put(char.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				field.setChar(bean,value.charAt(0));
			}
		});
		
		securityHandler.put(Character.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				field.setChar(bean,new Character(value.charAt(0)));
			}
		});
		
		securityHandler.put(String.class,new SecurityHandler() {
			public void handler(Field field,Object bean,String value) throws NumberFormatException, IllegalArgumentException, IllegalAccessException {
				field.setAccessible(true);
				field.set(bean, value);
			}
		});
		
	}
	
	public static void secureAssignment(Field field,Object bean,String value) {
		if(!securityHandler.containsKey(field.getType())) {
			throw new SecurityHandlerNotFoundException("未找到针对类型"+field.getType().toString()+"的赋值处理器!");
		}
		SecurityHandler handler = securityHandler.get(field.getType());
		try {
			handler.handler(field,bean,value);
		} catch (NumberFormatException e) {
			throw new TypeCastException("数字类型转换错误!",e);
		} catch (IllegalArgumentException e) {
			throw new TypeCastException("参数异常!",e);
		} catch (IllegalAccessException e) {
			throw new TypeCastException("访问对象属性出错!",e);
		}
	}
	
}
