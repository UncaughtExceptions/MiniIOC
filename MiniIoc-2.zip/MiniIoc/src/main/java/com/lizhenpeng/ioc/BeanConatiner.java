package com.lizhenpeng.ioc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Bean容器
 * Ioc容器
 * @author 出门左转
 *
 */
public class BeanConatiner {
	
	private Set<Bean> container;
	private Map<String,Object> ioc;
	
	{
		container = new HashSet<Bean>();
		ioc = new HashMap<String, Object>();
	}
	
	public void addBean(Bean bean) {
		container.add(bean);
	}
	
	public Bean getBean(String beanName) {
		Iterator<Bean> iterator = container.iterator();
		while(iterator.hasNext()) {
			Bean bean = iterator.next();
			if(bean.getBeanName().equals(beanName)) {
				return bean;
			}
		}
		return null;
	}	
	
	public void addIoc(String key,Object object) {
		ioc.put(key,object);
	}
	
	public boolean containIoc(String key) {
		return ioc.containsKey(key);
	}
	
	public Object getIoc(String key) {
		if(containIoc(key)) {
			return ioc.get(key);
		}
		return null;
	}

}
