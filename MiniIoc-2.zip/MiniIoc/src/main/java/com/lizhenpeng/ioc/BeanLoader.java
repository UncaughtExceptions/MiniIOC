package com.lizhenpeng.ioc;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.lizhenpeng.base.ReadXmlFileException;
import com.lizhenpeng.base.XMLFileNotFoundException;

/**
 * Bean配置加载器
 * @author 出门左转
 *
 */
public class BeanLoader {
	
	private BeanConatiner beanConatiner;
	
	public void setBeanContainer(BeanConatiner conatiner) {
		beanConatiner = conatiner;
	}
	
	public void Loader(String xmlPath) {
		if(!"".equals(xmlPath)) {
			String classLoaderPath = BeanLoader.class.getResource("/").getFile();
			String file = classLoaderPath.concat(xmlPath);
			File xmlFile = new File(file);
			if(!xmlFile.exists()) {
				throw new XMLFileNotFoundException("未找到文件"+file+"!");
			}
			try {
				readXxmlResource(xmlFile);
			} catch (DocumentException e) {
				throw new ReadXmlFileException("解析文件"+file+"出错!",e);
			}
		}
	}
	
	private void readXxmlResource(File xmlFile) throws DocumentException {
		SAXReader reader = new SAXReader();  
		Document document = reader.read(xmlFile);
		Element rootElement = document.getRootElement();
		List<Element> beanElement = rootElement.elements("bean");
		Iterator<Element> iterator = beanElement.iterator();
		while(iterator.hasNext()) {
			Element element = iterator.next();
			Bean bean = new Bean();
			bean.setBeanName(element.attributeValue("name"));
			bean.setBeanQualityName(element.attributeValue("class"));
			List<Element> propertyList = element.elements("property");
			Iterator<Element> propIte = propertyList.iterator();
			while(propIte.hasNext()) {
				Element prop = propIte.next();
				Property property = new Property();
				property.setPropertyName(prop.attributeValue("name"));
				if(prop.attribute("value") != null) {
					property.setPropertyValue(prop.attributeValue("value"));
					property.setReference(false);
					bean.addProperty(property);
				}
				if(prop.attribute("ref") != null) {
					property.setPropertyValue(prop.attributeValue("ref"));
					property.setReference(true);
					bean.addProperty(property);
				}
			}
			beanConatiner.addBean(bean);
		}
	}
	
}
