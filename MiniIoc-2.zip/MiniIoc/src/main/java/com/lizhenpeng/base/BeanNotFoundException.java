package com.lizhenpeng.base;

/**
 * 未找到相关的Bean
 * @author 出门左转
 *
 */
public class BeanNotFoundException extends RuntimeException{
	public BeanNotFoundException(String errorMessage) {
		super(errorMessage);
	}
}
