package com.lizhenpeng.ioc;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Bean容器
 * Ioc容器
 * @author 出门左转
 *
 */
public class BeanCache {
	
	private Set<Bean> beanCache;
	private Map<String,Object> instanceCache;
	private Map<Bean,Class<?>> beanClassCache;
	private Map<String,String> propertiesCache;
	
	{
		beanCache = new HashSet<Bean>();
		instanceCache = new HashMap<String, Object>();
		beanClassCache = new HashMap<Bean, Class<?>>();
		propertiesCache = new HashMap<String, String>();
	}
	
	public void addBean(Bean bean) {
		beanCache.add(bean);
	}
	
	public Bean getBean(String beanName) {
		Iterator<Bean> iterator = beanCache.iterator();
		while(iterator.hasNext()) {
			Bean bean = iterator.next();
			if(bean.getBeanName().equals(beanName)) {
				return bean;
			}
		}
		return null;
	}	
	
	public void addBeanClass(Bean bean,Class<?> beanClass) {
		beanClassCache.put(bean, beanClass);
	}
	
	public Class<?> getBeanClass(Bean bean){
		return beanClassCache.get(bean);
	}
	
	public Map<Bean,Class<?>> getBeanClassCacheInstance(){
		return beanClassCache;
	}
	
	public void addBeanInstance(String beanName,Object object) {
		instanceCache.put(beanName,object);
	}
	
	public boolean containBeanInstance(String beanName) {
		return instanceCache.containsKey(beanName);
	}
	
	public Object getBeanInstance(String beanName) {
		return instanceCache.get(beanName);
	}
	
	public Set<Bean> getBeanCacheInstance(){
		return beanCache;
	}
	
	public void addProperties(String propertiesName,String propertiesValue) {
		propertiesCache.put(propertiesName, propertiesValue);
	}
	
	public String getProperties(String propertiesName) {
		return propertiesCache.get(propertiesName);
	}

}
