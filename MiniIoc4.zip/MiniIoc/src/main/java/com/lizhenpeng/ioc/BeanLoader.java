package com.lizhenpeng.ioc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.lizhenpeng.base.BeanFactoryLoaderClassException;
import com.lizhenpeng.base.BeanPropertiesConfigException;
import com.lizhenpeng.base.PropertiesFileNotFound;
import com.lizhenpeng.base.ReadXmlFileException;
import com.lizhenpeng.base.XMLFileNotFoundException;

/**
 * Bean配置加载器
 * @author 出门左转
 *
 */
public class BeanLoader {

	private BeanCache beanCache;
	
	public void setBeanContainer(BeanCache conatiner) {
		beanCache = conatiner;
	}

	public void Loader(String xmlPath) {
		if (!"".equals(xmlPath)) {
			String classLoaderPath = BeanLoader.class.getResource("/").getFile();
			String file = classLoaderPath.concat(xmlPath);
			File xmlFile = new File(file);
			if (!xmlFile.exists()) {
				throw new XMLFileNotFoundException("未找到文件" + file + "!");
			}
			try {
				readXmlResource(xmlFile);
				loadBeanClass();
			} catch (DocumentException e) {
				throw new ReadXmlFileException("解析文件" + file + "出错!", e);
			}
		}
	}

	private void readXmlResource(File xmlFile) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(xmlFile);
		Element rootElement = document.getRootElement();
		List<Element> beanElement = rootElement.elements("bean");
		Iterator<Element> iterator = beanElement.iterator();
		while (iterator.hasNext()) {
			Element element = iterator.next();
			Bean bean = new Bean();
			bean.setBeanName(element.attributeValue("name"));
			bean.setBeanQualityName(element.attributeValue("class"));
			if (element.attribute("autoWired") != null &&
					element.attributeValue("autoWired").equals("true")) {
				bean.setAutoWired(true);
			}
			List<Element> propertyList = element.elements("property");
			Iterator<Element> propIte = propertyList.iterator();
			while (propIte.hasNext()) {
				Element prop = propIte.next();
				Property property = new Property();
				String propertiesName = prop.attributeValue("name");
				if(propertiesName == null) {
					throw new BeanPropertiesConfigException("Bean"+bean.getBeanName()+"属性配置错误!");
				}
				property.setPropertyName(propertiesName);
				if (prop.attribute("value") != null) {
					property.setPropertyValue(prop.attributeValue("value"));
					property.setReference(false);
					bean.addProperty(property);
				}
				if (prop.attribute("ref") != null) {
					property.setPropertyValue(prop.attributeValue("ref"));
					property.setReference(true);
					bean.addProperty(property);
				}
			}
			bean.setLoader(this);
			beanCache.addBean(bean);
		}
		List<Element> importElement = rootElement.elements("import");
		List<String> propertiesFile = new ArrayList<String>();
		if(importElement != null) {
			Iterator<Element> importElementIte = importElement.iterator();	
			while(importElementIte.hasNext()) {
				Element element = importElementIte.next();
				if(element.attributeValue("value") != null) {
					propertiesFile.add(element.attributeValue("value"));
				}
			}
		}
		loadPropertiesFile(propertiesFile);
	}
	
	private void loadBeanClass() {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		Set<Bean> beanCacheSet = beanCache.getBeanCacheInstance();
		Iterator<Bean> beanIterator = beanCacheSet.iterator();
		while(beanIterator.hasNext()) {
			Bean bean = beanIterator.next();
			String beanQualityName = bean.getBeanQualityName();
			try {
				Class<?> beanClass  =loader.loadClass(beanQualityName);
				beanCache.addBeanClass(bean, beanClass);
			} catch (ClassNotFoundException e) {
				throw new BeanFactoryLoaderClassException("无法加载当前类"+beanQualityName);
			}
		}
	}
	
	private void loadPropertiesFile(List<String> propertiesList) {
		String classLoaderPath = BeanLoader.class.getResource("/").getFile();
		Iterator<String> propertiesIte = propertiesList.iterator();
		while(propertiesIte.hasNext()) {
			String prop = propertiesIte.next();
			Properties propertiesLoader = new Properties();
			try {
				propertiesLoader.load(new FileInputStream(new File(classLoaderPath.concat(prop))));
				Set<Object> keySet = propertiesLoader.keySet();
				Iterator<Object> iterator = keySet.iterator();
				while(iterator.hasNext()) {
					String 	key = (String)iterator.next();
					String value = propertiesLoader.getProperty(key);
					beanCache.addProperties(key,value);
				}
			} catch (FileNotFoundException e) {
				throw new PropertiesFileNotFound("无法找到属性文件"+prop+"!");
			} catch (IOException e) {
				throw new PropertiesFileNotFound("读取属性文件"+prop+"出错!");
			}
		}
		
	}

}
