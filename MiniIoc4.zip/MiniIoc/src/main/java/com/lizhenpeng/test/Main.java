package com.lizhenpeng.test;

public class Main {
	private PrtClass prtClass;
	
	public void callPrt() {
		System.out.println("Main被调用");
	}
}
