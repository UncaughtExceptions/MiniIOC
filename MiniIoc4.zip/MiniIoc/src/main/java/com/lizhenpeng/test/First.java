package com.lizhenpeng.test;

public class First {

	private PrtClass prtClass;
	private Main mainClass;
	
	public void callAll() {
		prtClass.sayHello();
		mainClass.callPrt();
	}
	
}
