package com.lizhenpeng.test;

public class PrtClass {
	
	private String name;
	private Integer number;
	private int size;
	
	public void sayHello() {
		System.out.println("String:name "+name+" Integer:number "+number+" int:size "+size);
	}
}
