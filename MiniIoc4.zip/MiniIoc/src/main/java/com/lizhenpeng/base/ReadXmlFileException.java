package com.lizhenpeng.base;

/**
 * 解析XML文件出错
 * @author 出门左转
 *
 */
public class ReadXmlFileException extends RuntimeException{
	public ReadXmlFileException(String errorMessage,Throwable throwable) {
		super(errorMessage,throwable);
	}
}
