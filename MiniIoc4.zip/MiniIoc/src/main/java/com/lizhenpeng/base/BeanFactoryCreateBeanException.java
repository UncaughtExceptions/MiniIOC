package com.lizhenpeng.base;

/**
 * 反射实例化对象出错
 * @author 出门左转
 *
 */
public class BeanFactoryCreateBeanException extends RuntimeException{
	public BeanFactoryCreateBeanException(String errorMessage) {
		super(errorMessage);
	}
}
