package com.lizhenpeng.base;

/**
 * 加载属性文件错误
 * @author 出门左转
 *
 */
public class PropertiesFileNotFound extends RuntimeException{
	public PropertiesFileNotFound(String errorMessag) {
		super(errorMessag);
	}
}
