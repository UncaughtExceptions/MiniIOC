import org.junit.Test;

import com.lizhenpeng.ioc.BeanLoader;

public class BeanLoaderTest {
	
	@Test
	public void beanLoaderTest() {
		BeanLoader loader = new BeanLoader();
		loader.Loader("beans.xml");
	}
	
	
}
