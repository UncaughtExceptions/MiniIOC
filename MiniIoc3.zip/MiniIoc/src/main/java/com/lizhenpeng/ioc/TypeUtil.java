package com.lizhenpeng.ioc;

import java.util.regex.Pattern;

/**
 * 类型检查
 * @author 出门左转
 *
 */
public class TypeUtil {
	
	public static boolean isNumber(String value) {
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");    
	    return pattern.matcher(value).matches();    
	}
	
	public static boolean isFloat(String value) {
		Pattern pattern = Pattern.compile("^[0-9]+(.[0-9]+)?$");
		return pattern.matcher(value).matches();
	}
	
}
