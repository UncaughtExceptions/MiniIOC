package com.lizhenpeng.ioc;

import java.util.ArrayList;
import java.util.List;

import com.lizhenpeng.base.BeanCreateType;

/**
 * Bean的具体实现
 * 如果两个beanName相同则只会加载一次
 * @author 出门左转
 * 
 */
public class Bean {
	
	private String beanName;
	private String beanQualityName;
	private List<Property> properties;
	private boolean AutoWired;
	private BeanCreateType createType;
	
	{
		properties = new ArrayList<Property>();
		AutoWired = false;
		createType = BeanCreateType.signled;
	}
	
	public boolean isAutoWired() {
		return AutoWired;
	}

	public void setAutoWired(boolean autoWired) {
		AutoWired = autoWired;
	}

	public BeanCreateType getCreateType() {
		return createType;
	}

	public void setCreateType(BeanCreateType createType) {
		this.createType = createType;
	}

	public String getBeanName() {
		return beanName;
	}
	
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	
	public String getBeanQualityName() {
		return beanQualityName;
	}

	public void setBeanQualityName(String beanQualityName) {
		this.beanQualityName = beanQualityName;
	}
	
	public List<Property> getProperties() {
		return properties;
	}
	
	public void addProperty(Property property) {
		properties.add(property);
	}
	
	@Override
	public int hashCode() {
		if(beanName == null) {
			return super.hashCode();
		}
		return beanName.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj == this) {
			return true;
		}
		if(obj instanceof Bean) {
			Bean bean = (Bean)obj;
			if(bean.getBeanName().equals(beanName)) {
				return true;
			}
		}
		return false;
	}
	
}
