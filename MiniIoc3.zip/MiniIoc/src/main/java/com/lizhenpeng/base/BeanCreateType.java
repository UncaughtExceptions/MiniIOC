package com.lizhenpeng.base;

public enum BeanCreateType {
	signled,property;
}
