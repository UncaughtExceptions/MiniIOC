package com.lizhenpeng.base;

/**
 * 未找到指定的类
 * @author 出门左转
 *
 */
public class BeanFactoryLoaderClassException extends RuntimeException{
	public BeanFactoryLoaderClassException(String errorMessage) {
		super(errorMessage);
	}
}
