package com.lizhenpeng.test;

public class AImpl implements AInterface{
	
	private String say;
	
	public void callA() {
		System.out.println(say);
	}
	
}
