package com.lizhenpeng.test;

public interface AInterface {
	public void callA();
}
