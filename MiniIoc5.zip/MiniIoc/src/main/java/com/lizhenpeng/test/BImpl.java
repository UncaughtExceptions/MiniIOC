package com.lizhenpeng.test;

public class BImpl implements BInterface{
	
	private String say;
	
	public void callB() {
		System.out.println(say);
	}
}
