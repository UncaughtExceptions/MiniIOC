package com.lizhenpeng.ioc;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lizhenpeng.base.BeanFactoryCreateBeanException;
import com.lizhenpeng.base.BeanFactoryLoaderClassException;
import com.lizhenpeng.base.BeanNotFoundException;
import com.lizhenpeng.base.TypeCastException;

/**
 * Bean工厂
 * @author 出门左转
 *
 */
public class BeanFactory {
	
	private BeanCache beanCache;
	private ClassLoader classLoader;
	
	public void setBeanContainer(BeanCache conatiner) {
		beanCache = conatiner;
		classLoader = Thread.currentThread().getContextClassLoader();
	}
	
	private void createBean(String beanName) {
		if(beanCache.containBeanInstance(beanName)) {
			return;
		}
		Bean bean = beanCache.getBean(beanName);
		String propertyName = null;
		if(bean == null) {
			throw new BeanNotFoundException("容器中未找到命名为"+beanName+"的Bean");
		}
		try {
			String beanQualityName = bean.getBeanQualityName();
			Class<?> beanClass = classLoader.loadClass(beanQualityName);
			Object beanIns = beanClass.newInstance();
			List<Property> properties = bean.getProperties();
			Iterator<Property> propIte = properties.iterator();
			while(propIte.hasNext()) {
				Property property = propIte.next();
 				propertyName = property.getPropertyName();
				if(bean.isAutoWired() && property.isAutoWired()) {
					Field field = beanClass.getDeclaredField(propertyName);
					Class<?> propertyClass = field.getType();
					Map<Bean,Class<?>> beanClassCache = beanCache.getBeanClassCacheInstance();
					Set<Bean> beanSet = beanClassCache.keySet();
					Iterator<Bean> beanIterator = beanSet.iterator();
					while(beanIterator.hasNext()) {
						Bean compareBean = beanIterator.next();
						Class<?> compareBeanClass = beanCache.getBeanClass(compareBean);
						if(propertyClass == compareBeanClass && !propertyClass.isInterface()) {
							createBean(compareBean.getBeanName());
							Object reflectBean = beanCache.getBeanInstance(compareBean.getBeanName());
							field.setAccessible(true);
							field.set(beanIns,reflectBean);
							continue;
						}
						if(propertyClass.isAssignableFrom(compareBeanClass) && !compareBeanClass.isInterface()) {
							createBean(compareBean.getBeanName());
							Object reflectBean = beanCache.getBeanInstance(compareBean.getBeanName());
							field.setAccessible(true);
							field.set(beanIns,reflectBean);
							continue;
						}
					}
				}else {
					String propertyValue = property.getPropertyValue();
					Field propertyField = beanClass.getDeclaredField(propertyName);
					propertyField.setAccessible(true);
					if(!property.isReference()) {
						TypeHandler.secureAssignment(beanCache,propertyField,beanIns,propertyValue);
					}else {
						createBean(property.getPropertyValue());
						Object afixProperty = beanCache.getBeanInstance(property.getPropertyValue());
						propertyField.set(beanIns,afixProperty);
					}
				}
			}
			beanCache.addBeanInstance(beanName,beanIns);
		} catch (ClassNotFoundException e) {
			throw new BeanFactoryLoaderClassException("未找到指定的类"+bean.getBeanQualityName());
		} catch (InstantiationException e) {
			throw new BeanFactoryCreateBeanException("实例化类对象"+bean.getBeanQualityName()+"出错!");
		} catch (IllegalAccessException e) {
			throw new TypeCastException("访问对象属性出错!",e);
		} catch (NoSuchFieldException e) {
			throw new BeanFactoryCreateBeanException(bean.getBeanQualityName()+"字段"+propertyName+"不存在!");
		} catch (SecurityException e) {
			throw new BeanFactoryCreateBeanException(bean.getBeanQualityName()+"安全管理器验证失败!");
		}
	}
	
	public Object getBean(String beanName) {
		if(!beanCache.containBeanInstance(beanName)) {
			createBean(beanName);
		}
		return beanCache.getBeanInstance(beanName);
	}
	
}
