package com.lizhenpeng.ioc;

public class XmlApplicationContext {
	
	private BeanCache beanConatiner;
	private BeanFactory beanFactory;
	private BeanLoader beanLoader;
	
	{
		beanLoader = new BeanLoader();
		beanConatiner = new BeanCache();
		beanFactory = new BeanFactory();
		beanLoader.setBeanContainer(beanConatiner);
		beanFactory.setBeanContainer(beanConatiner);
	}
	
	public XmlApplicationContext(String xml) {
		loader(xml);
	}

	public void loader(String xml) {
		beanLoader.Loader(xml);
	}
	
	public Object getBean(String beanName) {
		return beanFactory.getBean(beanName);
	}
	
}
