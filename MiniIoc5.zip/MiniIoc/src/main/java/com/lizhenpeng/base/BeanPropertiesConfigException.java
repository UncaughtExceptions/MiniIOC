package com.lizhenpeng.base;

/**
 * 读取属性出错
 * @author 出门左转
 *
 */
public class BeanPropertiesConfigException extends RuntimeException{
	public BeanPropertiesConfigException(String errorMessage) {
		super(errorMessage);
	}
}
