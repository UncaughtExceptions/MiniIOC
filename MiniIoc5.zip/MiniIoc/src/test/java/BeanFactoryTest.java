import org.junit.Test;

import com.lizhenpeng.ioc.BeanCache;
import com.lizhenpeng.ioc.BeanFactory;
import com.lizhenpeng.ioc.BeanLoader;

public class BeanFactoryTest {

	@Test
	public void getBeanTest() {
		BeanCache conatiner = new BeanCache();
		BeanLoader beanLoader = new BeanLoader();
		beanLoader.setBeanContainer(conatiner);
		beanLoader.Loader("beans.xml");
		BeanFactory factory = new BeanFactory();
		factory.setBeanContainer(conatiner);
	}
	
}
