import java.sql.SQLException;
import java.text.ParseException;

import org.junit.Test;

import com.lizhenpeng.ioc.XmlApplicationContext;
import com.lizhenpeng.test.BImpl;
import com.lizhenpeng.test.BInterface;
import com.lizhenpeng.test.TestAutoWired;

public class ApplicationContextTest {
	
	@Test
	public void getBeanTest() throws SQLException, ParseException {
		XmlApplicationContext context = new XmlApplicationContext("beans.xml");
		TestAutoWired test = (TestAutoWired)context.getBean("test");
		test.call();
		BInterface b = (BImpl)context.getBean("b");
		b.callB();
	}
	
}
