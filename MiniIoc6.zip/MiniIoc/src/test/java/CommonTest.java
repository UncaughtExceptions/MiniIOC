import java.io.File;

import org.junit.Test;

public class CommonTest {
	
	@Test
	public void testClassPath() {
		System.out.println(Thread.currentThread().getContextClassLoader().getResource("").getFile());
		String dir = Thread.currentThread().getContextClassLoader().getResource("").getFile();
		File file = new File(dir);
		System.out.println(file.exists());
	}

}
