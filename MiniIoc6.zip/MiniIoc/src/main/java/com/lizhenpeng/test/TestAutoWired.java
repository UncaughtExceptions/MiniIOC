package com.lizhenpeng.test;

public class TestAutoWired {
	
	private AInterface aInterface;
	private BInterface bInterface;
	
	public void call() {
		aInterface.callA();
		bInterface.callB();
	}
	
}
