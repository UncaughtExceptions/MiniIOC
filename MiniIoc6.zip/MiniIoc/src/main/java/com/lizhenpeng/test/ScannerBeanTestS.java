package com.lizhenpeng.test;

import com.lizhenpeng.base.Test;
import com.lizhenpeng.ioc.XmlApplicationContext;

public class ScannerBeanTestS {
	
	public static void main(String[] argv) {
		XmlApplicationContext context = new XmlApplicationContext("beans.xml");
		Test test = (Test)context.getBean("test");
		test.test();
	}
	
}
