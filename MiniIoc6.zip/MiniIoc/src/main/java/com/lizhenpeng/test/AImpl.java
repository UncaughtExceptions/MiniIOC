package com.lizhenpeng.test;

public class AImpl implements AInterface{
	
	private String say;
	private int number;
	private char ch;
	
	public void callA() {
		System.out.println(say+"  "+number+"  "+ch);
	}
	
}
