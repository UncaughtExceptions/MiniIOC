package com.lizhenpeng.test;

import com.lizhenpeng.annotation.Component;
import com.lizhenpeng.annotation.SetValue;

@Component
public class AImpl implements AInterface{
	
	@SetValue("Aimpl say")
	private String say;
	@SetValue("Aimpl number")
	private String number;
	@SetValue("A")
	private char ch;
	
	public void callA() {
		System.out.println(say+"  "+number+"  "+ch);
	}
	
}
