package com.lizhenpeng.base;

/**
 * 未找到适合的属性类型处理器
 * @author 出门左转
 *
 */
public class SecurityHandlerNotFoundException extends RuntimeException{
	
	public SecurityHandlerNotFoundException(String errorMessage) {
		super(errorMessage);
	}
	
}
