package com.lizhenpeng.base;

/**
 * XML配置文件未发现
 * @author 出门左转
 *
 */
public class XMLFileNotFoundException extends RuntimeException{
	public XMLFileNotFoundException(String errorMessage) {
		super(errorMessage);
	}
}
