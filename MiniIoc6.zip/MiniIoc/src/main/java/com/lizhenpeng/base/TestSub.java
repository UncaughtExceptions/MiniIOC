package com.lizhenpeng.base;

public class TestSub extends Test{
	public void say() {
		System.out.println("say");
	}
}
