package com.lizhenpeng.base;

public class Test {
	public void test() {
		System.out.println("hello world");
	}
}
