package com.lizhenpeng.ioc;

import java.io.File;

/**
 * 工具类
 * @author 出门左转
 *
 */
public class ClassUtil {
	
	public static boolean validateClass(File classFile) {
		if(classFile.exists() && classFile.canRead()) {
			return true;
		}
		return false;
	}
	
	public static boolean isClassFile(File classFile) {
		return classFile.isFile() && classFile.getName().endsWith(".class");
	}
	
	public static boolean isPackage(File classFile) {
		return classFile.isDirectory();
	}
	
	public static String firstCharToLowerCase(String beanName) {
		beanName = beanName.toLowerCase().substring(0,1).concat(beanName.substring(1));
		return beanName;
	}
	
}
