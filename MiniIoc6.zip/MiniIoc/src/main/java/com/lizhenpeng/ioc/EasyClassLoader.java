package com.lizhenpeng.ioc;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import com.lizhenpeng.base.ScannerClassException;

/**
 * 文件流类加载器
 * @author 出门左转
 */
public class EasyClassLoader extends ClassLoader{
	
	public Class<?> easyLoaderClass(String className,String classFilePath) throws IOException {
		File classFile = new File(classFilePath);
		if(classFile.exists()) {
			ByteArrayOutputStream classData = new ByteArrayOutputStream();
			int hasRead = -1;
			byte[] buffer = new byte[2048];
			BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(classFile));
			while((hasRead = inputStream.read(buffer)) > 0) {
				classData.write(buffer,0,hasRead);
			}
			byte[] classCompleteData = classData.toByteArray();
			inputStream.close();
			classData.close();
			return defineClass(className,classCompleteData,0,classCompleteData.length);
		}
		throw new ScannerClassException("未找到类"+className+"定义!");
	}
	
}
