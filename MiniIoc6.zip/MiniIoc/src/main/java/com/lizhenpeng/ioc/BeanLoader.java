package com.lizhenpeng.ioc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.lizhenpeng.base.BeanCreateType;
import com.lizhenpeng.base.BeanFactoryLoaderClassException;
import com.lizhenpeng.base.BeanPropertiesConfigException;
import com.lizhenpeng.base.PropertiesFileNotFound;
import com.lizhenpeng.base.ReadXmlFileException;
import com.lizhenpeng.base.ScannerClassException;
import com.lizhenpeng.base.XMLFileNotFoundException;

/**
 * Bean配置加载器
 * @author 出门左转
 *
 */
public class BeanLoader {

	private BeanCache beanCache;
	private ClassLoader classLoader;
	
	public void setBeanContainer(BeanCache conatiner) {
		beanCache = conatiner;
	}
	
	public ClassLoader getClassLoader() {
		return classLoader;
	}
	
	public void setClassLoader(ClassLoader loader) {
		classLoader = loader;
	}

	public void Loader(String xmlPath) {
		if (!"".equals(xmlPath)) {
			String classLoaderPath = BeanLoader.class.getResource("/").getFile();
			String file = classLoaderPath.concat(xmlPath);
			File xmlFile = new File(file);
			if (!xmlFile.exists()) {
				throw new XMLFileNotFoundException("未找到文件" + file + "!");
			}
			try {
				readXmlResource(xmlFile);
				loadBeanClass();
			} catch (DocumentException e) {
				throw new ReadXmlFileException("解析文件" + file + "出错!", e);
			}
		}
	}

	private void readXmlResource(File xmlFile) throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(xmlFile);
		Element rootElement = document.getRootElement();
		List<Element> beanElement = rootElement.elements("bean");
		Iterator<Element> iterator = beanElement.iterator();
		while (iterator.hasNext()) {
			Element element = iterator.next();
			Bean bean = new Bean();
			bean.setBeanName(element.attributeValue("name"));
			bean.setBeanQualityName(element.attributeValue("class"));
			if (element.attribute("autoWired") != null &&
					element.attributeValue("autoWired").equals("true")) {
				bean.setAutoWired(true);
			}
			List<Element> propertyList = element.elements("property");
			Iterator<Element> propIte = propertyList.iterator();
			while (propIte.hasNext()) {
				Element prop = propIte.next();
				Property property = new Property();
				String propertiesName = prop.attributeValue("name");
				if(propertiesName == null) {
					throw new BeanPropertiesConfigException("Bean"+bean.getBeanName()+"属性配置错误!");
				}
				property.setPropertyName(propertiesName);
				if (prop.attribute("value") != null) {
					property.setPropertyValue(prop.attributeValue("value"));
					property.setReference(false);
					bean.addProperty(property);
					continue;
				}
				if (prop.attribute("ref") != null) {
					property.setPropertyValue(prop.attributeValue("ref"));
					property.setReference(true);
					bean.addProperty(property);
					continue;
				}
				property.setAutoWired(true);
				bean.addProperty(property);
			}
			bean.setLoader(this);
			beanCache.addBean(bean);
		}
		List<Element> importElement = rootElement.elements("import");
		List<String> propertiesFile = new ArrayList<String>();
		if(importElement != null) {
			Iterator<Element> importElementIte = importElement.iterator();	
			while(importElementIte.hasNext()) {
				Element element = importElementIte.next();
				if(element.attributeValue("value") != null) {
					propertiesFile.add(element.attributeValue("value"));
				}
			}
		}
		loadPropertiesFile(propertiesFile);
		List<Element> packageElement = rootElement.elements("package");
		List<String> packageList = new ArrayList<String>();
		if(packageElement != null) {
			Iterator<Element> packageElementIte = packageElement.iterator();	
			while(packageElementIte.hasNext()) {
				Element element = packageElementIte.next();
				if(element.attributeValue("package-name") != null) {
					packageList.add(element.attributeValue("package-name"));
				}
			}
		}
		scanPackage(packageList);
	}
	
	private void loadBeanClass() {
		Set<Bean> beanCacheSet = beanCache.getBeanCacheInstance();
		Iterator<Bean> beanIterator = beanCacheSet.iterator();
		while(beanIterator.hasNext()) {
			Bean bean = beanIterator.next();
			String beanQualityName = bean.getBeanQualityName();
			try {
				Class<?> beanClass  = classLoader.loadClass(beanQualityName);
				beanCache.addBeanClass(bean, beanClass);
			} catch (ClassNotFoundException e) {
				throw new BeanFactoryLoaderClassException("无法加载当前类"+beanQualityName);
			}
		}
	}
	
	private void loadPropertiesFile(List<String> propertiesList) {
		String classLoaderPath = BeanLoader.class.getResource("/").getFile();
		Iterator<String> propertiesIte = propertiesList.iterator();
		while(propertiesIte.hasNext()) {
			String prop = propertiesIte.next();
			Properties propertiesLoader = new Properties();
			try {
				propertiesLoader.load(new FileInputStream(new File(classLoaderPath.concat(prop))));
				Set<Object> keySet = propertiesLoader.keySet();
				Iterator<Object> iterator = keySet.iterator();
				while(iterator.hasNext()) {
					String 	key = (String)iterator.next();
					String value = propertiesLoader.getProperty(key);
					beanCache.addProperties(key,value);
				}
			} catch (FileNotFoundException e) {
				throw new PropertiesFileNotFound("无法找到属性文件"+prop+"!");
			} catch (IOException e) {
				throw new PropertiesFileNotFound("读取属性文件"+prop+"出错!");
			}
		}	
	}
	
	private void scanPackage(List<String> packageList) {
		Iterator<String> iterator = packageList.iterator();
		String rootPath = BeanLoader.class.getResource("/").getFile();
		while(iterator.hasNext()) {
			String packageName = iterator.next();
			String packagrDir = packageName.replace(".",File.separator);
			String classFileAbsolutePath = rootPath.concat(packagrDir).concat("/");
			scannerClass(packageName,classFileAbsolutePath);
		}
	}
	
	private void scannerClass(String basePackage,String classFileAbsolutePath) {
		File classFile = new File(classFileAbsolutePath);
		if(ClassUtil.validateClass(classFile)) {
			if(ClassUtil.isClassFile(classFile)) {
				String classSimpleName = classFile.getName();
				classSimpleName = classSimpleName.substring(0,classSimpleName.indexOf("."));
				String classQualityName = basePackage.concat(".").concat(classSimpleName);
				try {
					Class<?> classType = classLoader.loadClass(classQualityName);
					String beanName = classType.getName();
					beanName = ClassUtil.firstCharToLowerCase(beanName.substring(beanName.lastIndexOf(".") + 1));
					Bean bean = new Bean();
					bean.setLoader(this);
					bean.setBeanName(beanName);
					bean.setBeanQualityName(classType.getName());
					beanCache.addBean(bean);
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
			if(ClassUtil.isPackage(classFile)) {
				String[] classFileList = classFile.list();
				for(String classFileName : classFileList) {
					String curPath = classFileAbsolutePath.concat(File.separator).concat(classFileName);
					String curPackage = basePackage;
					File validateFile = new File(curPath);
					if(ClassUtil.isPackage(validateFile)) {
						curPackage = basePackage.concat(".").concat(classFileName);
					}
					scannerClass(curPackage,curPath);
				}
			}
		}
	}	

}
