package com.lizhenpeng.ext;

import com.lizhenpeng.ioc.XmlApplicationContext;
import com.lizhenpeng.test.TestAutoWired;

public class ScannerBeanTest {
	
	public static void main(String[] argv) {
		XmlApplicationContext context = new XmlApplicationContext("beans.xml");
		TestAutoWired test = (TestAutoWired)context.getBean("testAutoWired");
		test.call();
	}
}
